"use strict";
(self["webpackChunkjupyterlite_embedded_kernel"] = self["webpackChunkjupyterlite_embedded_kernel"] || []).push([["lib_index_js"],{

/***/ "./lib/components/Card.js":
/*!********************************!*\
  !*** ./lib/components/Card.js ***!
  \********************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Card = void 0;
class Card {
    constructor(props, onClick) {
        this.element = document.createElement('div');
        this.element.className = 'welcome-card';
        this.element.addEventListener('click', onClick);
        this.processCardUI(props);
    }
    processCardUI(props) {
        props = props;
        this.element.innerHTML = `
      <div class="card-content">
        <span class="welcome-icon">${props.icon}</span>
        <div>
          <h3 class="card-title">${props.title}</h3>
          <p class="card-description">${props.description}</p>
        </div>
      </div>
    `;
    }
    getElement() {
        return this.element;
    }
}
exports.Card = Card;


/***/ }),

/***/ "./lib/components/ConnectCard.js":
/*!***************************************!*\
  !*** ./lib/components/ConnectCard.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ConnectCard = void 0;
const Card_1 = __webpack_require__(/*! ./Card */ "./lib/components/Card.js");
class ConnectCard extends Card_1.Card {
    async connect_disconnect() {
        if (!this.deviceService.isConnected()) {
            this.element.classList.add('connecting');
            this.element.innerHTML = `
        <div class="card-content">
          <span class="welcome-icon device-icon waiting">⟳</span>
          <div>
            <h3 class="card-title">Connecting...</h3>
            <p class="card-description">Please wait while we connect to your device</p>
          </div>
        </div>
      `;
            await this.deviceService.connect();
        }
    }
    constructor(props, deviceService) {
        super(props, () => this.connect_disconnect());
        this.deviceService = deviceService;
        document.addEventListener('deviceConnected', (event) => {
            this.processCardUI(props);
        });
    }
    processCardUI(props) {
        if (this.deviceService === undefined) {
            this.element.innerHTML = `
        <div class="card-content">
          <span class="welcome-icon">${props.icon || '🔌'}</span>
          <div>
            <h3 class="card-title">${props.title || 'Connect Device'}</h3>
            <p class="card-description">${props.description || 'Connect your device to get started'}</p>
          </div>
        </div>
      `;
            return;
        }
        if (this.deviceService.isConnected()) {
            this.element.innerHTML = `
        <div class="card-content">
          <span class="welcome-icon device-icon success">✓</span>
          <div>
            <h3 class="card-title">Device Connected</h3>
            <p class="card-description">
              Your device is already connected and ready to use.
              <span class="device-status">To reconnect, please refresh the page.</span>
            </p>
          </div>
        </div>
      `;
            this.element.classList.add('device-connected');
        }
    }
}
exports.ConnectCard = ConnectCard;


/***/ }),

/***/ "./lib/components/Dialog.js":
/*!**********************************!*\
  !*** ./lib/components/Dialog.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Dialog = void 0;
const Card_1 = __webpack_require__(/*! ./Card */ "./lib/components/Card.js");
const FlashCard_1 = __webpack_require__(/*! ./FlashCard */ "./lib/components/FlashCard.js");
const ConnectCard_1 = __webpack_require__(/*! ./ConnectCard */ "./lib/components/ConnectCard.js");
class Dialog {
    constructor(props) {
        this.element = document.createElement('div');
        this.element.className = 'welcome-overlay';
        this.element.addEventListener('click', (e) => {
            if (e.target === this.element) {
                props.closeDialog;
            }
        });
        const closeButton = this.createCloseButton(props.closeDialog);
        const header = this.createHeader();
        const optionsContainer = this.createOptionsContainer();
        this.connectCard = new ConnectCard_1.ConnectCard({
            action: 'connect',
            icon: '🔌',
            title: 'Connect Device',
            description: 'Connect to ESP32 device via serial',
            color: 'var(--ui-navy)'
        }, props.serviceContainer.deviceService);
        this.flashCard = new FlashCard_1.FlashCard({
            action: 'flash',
            icon: '⚡️',
            title: 'Flash Device',
            description: 'Flash your device with the latest firmware',
            color: 'var(--ui-red)'
        }, () => props.serviceContainer.flashService.flashDevice(), props.serviceContainer.firmwareService, props.serviceContainer.deviceService);
        this.resetCard = new Card_1.Card({
            action: 'reset-esp',
            icon: '🔄',
            title: 'Hard reset Esp',
            description: 'Hard reset esp chip',
            color: 'var(--ui-red)'
        }, () => props.serviceContainer.deviceService.reset());
        optionsContainer.appendChild(this.connectCard.getElement());
        optionsContainer.appendChild(this.flashCard.getElement());
        optionsContainer.appendChild(this.resetCard.getElement());
        let content = document.createElement('div');
        content.className = 'welcome-dialog';
        content.appendChild(closeButton);
        content.appendChild(header);
        content.appendChild(optionsContainer);
        this.element.appendChild(content);
    }
    createCloseButton(onCloseDialog) {
        const closeButton = document.createElement('button');
        closeButton.className = 'close-button';
        closeButton.innerHTML = '×';
        closeButton.addEventListener('click', onCloseDialog);
        return closeButton;
    }
    createHeader() {
        const header = document.createElement('div');
        header.innerHTML = '<h1 class="welcome-title">ESP32 Device Manager</h1>';
        return header;
    }
    createOptionsContainer() {
        const container = document.createElement('div');
        container.style.cssText = 'display: flex; flex-direction: column; gap: 1rem;';
        return container;
    }
    getElement() {
        return this.element;
    }
}
exports.Dialog = Dialog;


/***/ }),

/***/ "./lib/components/FlashCard.js":
/*!*************************************!*\
  !*** ./lib/components/FlashCard.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.FlashCard = void 0;
const Card_1 = __webpack_require__(/*! ./Card */ "./lib/components/Card.js");
class FlashCard extends Card_1.Card {
    constructor(props, onClick, firmwareService, deviceService) {
        super(props, onClick);
        this.firmwareService = firmwareService;
        this.deviceService = deviceService;
        this.deviceInfoElement = null;
        setTimeout(() => this.initializeFlashCard(), 0);
    }
    initializeFlashCard() {
        this.createFirmwareDropdown();
        if (this.dropdown) {
            this.handleDropdownClickEvents();
        }
        this.setupEventListeners();
    }
    setupEventListeners() {
        document.addEventListener('flashComplete', () => {
            this.updateDeviceInfo();
            if (this.dropdown) {
                this.dropdown.value = this.firmwareService.getSelectedFirmwareId();
            }
        });
    }
    createFirmwareDropdown() {
        try {
            this.cardContent = this.element.querySelector('.card-content');
            if (!this.cardContent) {
                console.error('Card content element not found');
                return;
            }
            const existingDropdown = this.cardContent.querySelector('.firmware-dropdown-container');
            if (existingDropdown) {
                console.log('Dropdown already exists, skipping creation');
                return;
            }
            const firmwareSection = document.createElement('div');
            firmwareSection.className = 'firmware-section';
            this.deviceInfoElement = document.createElement('div');
            this.deviceInfoElement.className = 'device-info';
            this.updateDeviceInfo();
            firmwareSection.appendChild(this.deviceInfoElement);
            const topDivider = document.createElement('div');
            topDivider.className = 'firmware-divider';
            firmwareSection.appendChild(topDivider);
            const dropdownContainer = document.createElement('div');
            dropdownContainer.className = 'firmware-dropdown-container';
            const label = document.createElement('label');
            label.className = 'firmware-dropdown-label';
            label.textContent = 'Firmware:';
            this.dropdown = document.createElement('select');
            this.dropdown.className = 'firmware-selector';
            const firmwareOptions = this.firmwareService.getFirmwareOptions();
            Object.entries(firmwareOptions).forEach(([id, option]) => {
                const optionElement = document.createElement('option');
                optionElement.value = id;
                optionElement.textContent = option.name;
                this.dropdown.appendChild(optionElement);
            });
            const deviceType = this.deviceService.getDeviceType();
            if (deviceType) {
                this.dropdown.value = 'auto';
                this.firmwareService.setSelectedFirmwareId('auto');
            }
            else {
                this.dropdown.value = this.firmwareService.getSelectedFirmwareId();
            }
            this.dropdown.addEventListener('change', () => {
                this.firmwareService.setSelectedFirmwareId(this.dropdown.value);
                this.updateDeviceInfo();
            });
            dropdownContainer.appendChild(label);
            dropdownContainer.appendChild(this.dropdown);
            firmwareSection.appendChild(dropdownContainer);
            this.cardContent.appendChild(firmwareSection);
            console.log('Dropdown added to card');
        }
        catch (error) {
            console.error('Error creating firmware dropdown:', error);
        }
    }
    handleDropdownClickEvents() {
        if (this.dropdown) {
            this.dropdown.addEventListener('click', (event) => {
                event.stopPropagation();
            });
        }
    }
    updateDeviceInfo() {
        if (!this.deviceInfoElement)
            return;
        const deviceType = this.deviceService.getDeviceType();
        const selectedFirmware = this.firmwareService.getSelectedFirmwareId();
        this.deviceInfoElement.innerHTML = ``;
        if (deviceType) {
            this.deviceInfoElement.innerHTML = `
        <div class="device-detected">
          <div class="device-detected-header">
            <span class="device-icon success">✓</span>
            <span class="device-status">Last connected device</span>
          </div>
          <div class="device-details">
            <span class="firmware-badge">${this.getRecommendedFirmwareForDevice(deviceType)}</span>
          </div>
        </div>
      `;
        }
        else if (selectedFirmware === 'Auto') {
            this.deviceInfoElement.innerHTML = `
        <div class="device-auto-mode">
          <div class="device-auto-header">
            <span class="device-icon waiting">🔍</span>
            <span class="device-status waiting">Auto-detection mode</span>
          </div>
          <div class="device-action-hint">
            When you click <strong>Flash</strong>, the appropriate firmware will be automatically selected based on your device type.
          </div>
        </div>
      `;
        }
        else {
            this.deviceInfoElement.innerHTML = `
        <div class="device-not-detected">
          <div class="device-auto-header">
            <span class="device-icon">🔧</span>
            <span class="device-status">Manual selection</span>
          </div>
          <div class="device-manual-mode">
            Will flash with <strong>${selectedFirmware}</strong> firmware regardless of device type
          </div>
        </div>
      `;
        }
        this.deviceInfoElement.style.display = 'block';
    }
    getRecommendedFirmwareForDevice(deviceType) {
        if (deviceType.includes('C6')) {
            return 'ESP32-C6';
        }
        else if (deviceType.includes('C3')) {
            return 'ESP32-C3';
        }
        else {
            return 'ESP32';
        }
    }
    update(props) {
        this.element.innerHTML = `
      <div class="card-content">
        <div class="card-header">
          <span class="welcome-icon">${props.icon}</span>
          <div>
            <h3 class="card-title">${props.title}</h3>
            <p class="card-description">${props.description}</p>
          </div>
        </div>
      </div>
    `;
        this.cardContent = this.element.querySelector('.card-content');
        setTimeout(() => this.initializeFlashCard(), 0);
    }
}
exports.FlashCard = FlashCard;


/***/ }),

/***/ "./lib/components/MinimizedButton.js":
/*!*******************************************!*\
  !*** ./lib/components/MinimizedButton.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MinimizedButton = void 0;
class MinimizedButton {
    constructor(onShow) {
        this.element = document.createElement('div');
        this.element.className = 'esp-button-container';
        this.element.title = 'Open ESP32 Device Manager';
        this.element.style.display = 'none';
        this.element.addEventListener('click', onShow);
        const minimizedButton = document.createElement('button');
        minimizedButton.className = 'minimized-button';
        const contentContainer = document.createElement('div');
        contentContainer.className = 'button-content';
        const img = document.createElement('img');
        img.src = 'https://www.cdnlogo.com/logos/e/41/espressif-systems.svg';
        img.alt = 'Espressif Systems Logo';
        contentContainer.appendChild(img);
        const statusWrapper = document.createElement('div');
        statusWrapper.className = 'status-wrapper';
        this.statusIndicator = document.createElement('span');
        this.statusIndicator.className = 'status-indicator';
        statusWrapper.appendChild(this.statusIndicator);
        this.deviceLabel = document.createElement('span');
        this.deviceLabel.className = 'device-label';
        this.deviceLabel.textContent = 'Not connected';
        statusWrapper.appendChild(this.deviceLabel);
        contentContainer.appendChild(statusWrapper);
        minimizedButton.appendChild(contentContainer);
        this.element.appendChild(minimizedButton);
    }
    show() {
        this.element.style.display = 'flex';
    }
    hide() {
        this.element.style.display = 'none';
    }
    getElement() {
        return this.element;
    }
    updateOnConnection(msg) {
        this.statusIndicator.classList.add('connected');
        this.deviceLabel.textContent = msg;
        this.element.title = `Open ESP32 Device Manager (${msg})`;
    }
    updateOnDisconnection(msg) {
        this.statusIndicator.classList.add('disconnected');
        this.deviceLabel.textContent = msg;
        this.element.title = `Open ESP32 Device Manager (${msg})`;
    }
}
exports.MinimizedButton = MinimizedButton;


/***/ }),

/***/ "./lib/components/ProgressOverlay.js":
/*!*******************************************!*\
  !*** ./lib/components/ProgressOverlay.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ProgressOverlay = void 0;
class ProgressOverlay {
    constructor() {
        this.element = document.createElement('div');
        this.element.className = 'progress-overlay';
        this.element.innerHTML = `
      <div class="progress-container">
        <div class="progress-title">Flashing Firmware...</div>
        <div class="progress-bar-container">
          <div class="progress-bar"></div>
        </div>
        <div class="progress-status">Initializing...</div>
      </div>
    `;
        this.progressBar = this.element.querySelector('.progress-bar');
        this.statusEl = this.element.querySelector('.progress-status');
        this.titleEl = this.element.querySelector('.progress-title');
    }
    show(firmwareId) {
        document.body.appendChild(this.element);
        // Update title with firmware information if provided
        if (firmwareId) {
            this.setTitle(`Flashing ${firmwareId} Firmware...`);
        }
        requestAnimationFrame(() => {
            this.element.classList.add('visible');
        });
        // Dispatch flashStart event with firmware info
        const flashStartEvent = new CustomEvent('flashStart', {
            detail: { firmware: firmwareId || 'selected' }
        });
        document.dispatchEvent(flashStartEvent);
    }
    async hide() {
        this.element.classList.remove('visible');
        await new Promise(resolve => setTimeout(resolve, 300));
        this.element.remove();
    }
    updateProgress(written, total) {
        const progress = (written / total) * 100;
        this.progressBar.style.width = `${progress}%`;
        this.statusEl.textContent = `Flashing: ${Math.round(progress)}% (${written} / ${total} bytes)`;
    }
    setStatus(status) {
        this.statusEl.textContent = status;
    }
    setTitle(title) {
        if (title.includes('Flashing') && title.includes('Firmware')) {
            const match = title.match(/Flashing (.+?) Firmware\.\.\./i);
            if (match && match[1]) {
                const firmwareName = match[1];
                this.titleEl.innerHTML = `Flashing <span class="firmware-name">${firmwareName}</span> Firmware...`;
            }
            else {
                this.titleEl.textContent = title;
            }
        }
        else {
            this.titleEl.textContent = title;
        }
    }
}
exports.ProgressOverlay = ProgressOverlay;


/***/ }),

/***/ "./lib/constants.js":
/*!**************************!*\
  !*** ./lib/constants.js ***!
  \**************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.firmwareOptions = void 0;
exports.firmwareOptions = {
    'auto': {
        name: 'Auto detection',
        url: ''
    },
    'esp32': {
        name: 'ESP32',
        url: 'https://horw.github.io/buffer/ESP32_GENERIC-20241129-v1.24.1.bin'
    },
    'esp32-c3': {
        name: 'ESP32-C3',
        url: 'https://horw.github.io/buffer/ESP32_GENERIC_C3-20241129-v1.24.1.bin'
    },
    'esp32-c6': {
        name: 'ESP32-C6',
        url: 'https://horw.github.io/buffer/ESP32_GENERIC_C6-20241129-v1.24.1.bin'
    }
};


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
const kernel_1 = __webpack_require__(/*! @jupyterlite/kernel */ "webpack/sharing/consume/default/@jupyterlite/kernel");
const kernel_2 = __webpack_require__(/*! ./kernel */ "./lib/kernel.js");
const panel_1 = __importDefault(__webpack_require__(/*! ./panel */ "./lib/panel.js"));
const ServiceContainer_1 = __webpack_require__(/*! ./services/ServiceContainer */ "./lib/services/ServiceContainer.js");
// Kernel plugin for the embedded kernel
const kernelPlugin = {
    id: 'jupyterlite-embedded-kernel:kernel',
    autoStart: true,
    requires: [kernel_1.IKernelSpecs],
    activate: (app, kernelspecs) => {
        const activeKernels = new Map();
        app.router.post('/api/kernels/(.*)/interrupt', async (req, kernelId) => {
            const kernel = activeKernels.get(kernelId);
            if (kernel) {
                try {
                    await kernel.interrupt();
                    return new Response(null, { status: 204 });
                }
                catch (error) {
                    console.error('Failed to interrupt kernel:', error);
                    return new Response('Failed to interrupt kernel', { status: 500 });
                }
            }
            return new Response('Kernel not found', { status: 404 });
        });
        kernelspecs.register({
            spec: {
                name: 'embedded',
                display_name: 'Embedded Kernel',
                language: 'python',
                argv: [],
                resources: {
                    'logo-32x32': 'https://www.cdnlogo.com/logos/e/41/espressif-systems.svg',
                    'logo-64x64': 'https://www.cdnlogo.com/logos/e/41/espressif-systems.svg',
                },
            },
            create: async (options) => {
                const serviceContainer = new ServiceContainer_1.ServiceContainer();
                const welcomePanel = new panel_1.default(serviceContainer);
                document.body.appendChild(welcomePanel.getElement());
                const kernel = new kernel_2.EmbeddedKernel(options, serviceContainer);
                welcomePanel.show();
                await kernel.ready;
                activeKernels.set(kernel.id, kernel);
                return kernel;
            }
        });
    }
};
exports["default"] = [kernelPlugin];


/***/ }),

/***/ "./lib/kernel.js":
/*!***********************!*\
  !*** ./lib/kernel.js ***!
  \***********************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.EmbeddedKernel = void 0;
const kernel_1 = __webpack_require__(/*! @jupyterlite/kernel */ "webpack/sharing/consume/default/@jupyterlite/kernel");
class EmbeddedKernel extends kernel_1.BaseKernel {
    constructor(options, serviceContainer) {
        super(options);
        this.serviceContainer = serviceContainer;
    }
    async kernelInfoRequest() {
        const content = {
            implementation: 'embedded',
            implementation_version: '0.1.0',
            language_info: {
                codemirror_mode: {
                    name: 'python',
                    version: 3,
                },
                file_extension: '.py',
                mimetype: 'text/x-python',
                name: 'python',
                nbconvert_exporter: 'python',
                pygments_lexer: 'ipython3',
                version: '3.8',
            },
            protocol_version: '5.3',
            status: 'ok',
            banner: 'Embedded Kernel with Serial Support',
            help_links: [],
        };
        return content;
    }
    async interrupt() {
        await this.serviceContainer.deviceService.sendInterrupt();
    }
    async executeRequest(content) {
        console.log("[Kernel] executeRequest - Starting execution");
        if (this.serviceContainer.deviceService == undefined) {
            console.log("[Kernel] executeRequest - DeviceService is undefined");
            return {
                status: 'error',
                execution_count: this.executionCount,
                ename: 'ValueError',
                evalue: 'Missing MicroPython firmware URL',
                traceback: ['Please provide MicroPython firmware URL']
            };
        }
        console.log("[Kernel] executeRequest - Processing code");
        const { code } = content;
        try {
            console.log("[Kernel] executeRequest - Checking transport");
            const transport = this.serviceContainer.deviceService.getTransport();
            console.log(transport);
            if (!transport) {
                console.log("[Kernel] executeRequest - No transport available");
                return {
                    status: 'error',
                    execution_count: this.executionCount,
                    ename: 'TransportError',
                    evalue: 'No transport available',
                    traceback: ['Please connect a device first']
                };
            }
            console.log("[Kernel] executeRequest - Executing command via ConsoleService");
            // Execute the command and handle the output
            const result = await this.serviceContainer.consoleService.executeCommand(code, (content) => {
                console.log("[Kernel] executeRequest - Streaming output:", content.text.substring(0, 50) + (content.text.length > 50 ? '...' : ''));
                this.stream(content);
            });
            if (!result.success) {
                console.log("[Kernel] executeRequest - Command execution failed:", result.error);
                return {
                    status: 'error',
                    execution_count: this.executionCount,
                    ename: 'ExecutionError',
                    evalue: result.error || 'Unknown error',
                    traceback: [result.error || 'Unknown error']
                };
            }
            console.log("[Kernel] executeRequest - Command executed successfully");
            return {
                status: 'ok',
                execution_count: this.executionCount,
                user_expressions: {},
            };
        }
        catch (error) {
            console.error("[Kernel] executeRequest - Execution error:", error);
            return {
                status: 'error',
                execution_count: this.executionCount,
                ename: 'ExecuteError',
                evalue: error instanceof Error ? error.message : 'Unknown error',
                traceback: error instanceof Error ? [error.stack || ''] : ['Unknown error occurred'],
            };
        }
    }
    async completeRequest(content) {
        throw new Error('Not implemented');
    }
    async inspectRequest(content) {
        throw new Error('Not implemented');
    }
    async isCompleteRequest(content) {
        throw new Error('Not implemented');
    }
    async commInfoRequest(content) {
        throw new Error('Not implemented');
    }
    inputReply(content) { }
    async commOpen(msg) { }
    async commMsg(msg) { }
    async commClose(msg) { }
}
exports.EmbeddedKernel = EmbeddedKernel;


/***/ }),

/***/ "./lib/panel.js":
/*!**********************!*\
  !*** ./lib/panel.js ***!
  \**********************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const styles_1 = __webpack_require__(/*! ./styles */ "./lib/styles.js");
const MinimizedButton_1 = __webpack_require__(/*! ./components/MinimizedButton */ "./lib/components/MinimizedButton.js");
const Dialog_1 = __webpack_require__(/*! ./components/Dialog */ "./lib/components/Dialog.js");
class DialogPanel {
    constructor(dialog) {
        this.element = document.createElement('div');
        this.element.id = 'dialog-widget-panel';
        this.element.appendChild(dialog.getElement());
    }
    show() {
        this.element.style.display = 'block';
        this.element.classList.remove('minimized');
        this.element.classList.add('visible');
        this.element.style.transition = 'opacity 0.3s ease-in-out';
        this.element.style.opacity = '1';
    }
    hide() {
        this.element.classList.add('minimizing');
        this.element.classList.remove('visible');
        this.element.style.opacity = '0';
        setTimeout(() => {
            this.element.style.display = 'none';
            this.element.classList.remove('minimizing');
            this.element.classList.add('minimized');
        }, 300);
    }
    getElement() {
        return this.element;
    }
}
class MinimizedPanel {
    constructor(minimizedButton) {
        this.minimizedButton = minimizedButton;
        this.element = document.createElement('div');
        this.element.id = 'minimized-panel-widget-panel';
        this.element.appendChild(minimizedButton.getElement());
    }
    show() {
        this.element.style.display = 'block';
        this.element.classList.remove('minimized');
        this.element.classList.add('visible');
        this.element.style.transition = 'opacity 0.3s ease-in-out';
        this.element.style.opacity = '1';
        this.minimizedButton.show();
    }
    hide() {
        this.element.classList.add('minimizing');
        this.element.classList.remove('visible');
        this.element.style.opacity = '0';
        this.minimizedButton.hide();
        setTimeout(() => {
            this.element.style.display = 'none';
            this.element.classList.remove('minimizing');
            this.element.classList.add('minimized');
        }, 300);
    }
    getElement() {
        return this.element;
    }
    updateOnConnection(msg) {
        this.minimizedButton.updateOnConnection(msg);
    }
    updateOnDisconnection(msg) {
        this.minimizedButton.updateOnDisconnection(msg);
    }
}
class WelcomePanel {
    constructor(serviceContainer) {
        this.serviceContainer = serviceContainer;
        this.element = document.createElement('div');
        this.element.id = 'jp-kernel-welcome-panel';
        let styleElement = document.createElement('style');
        styleElement.textContent = [
            styles_1.globalStyles,
            styles_1.animations,
            styles_1.overlayStyles,
            styles_1.dialogStyles,
            styles_1.minimizedStyles,
            styles_1.cardStyles,
            styles_1.buttonStyles,
            styles_1.progressOverlayStyles
        ].join('\n');
        document.head.appendChild(styleElement);
        const minimizedButton = new MinimizedButton_1.MinimizedButton(() => this.show());
        this.minimizedPanel = new MinimizedPanel(minimizedButton);
        const dialog = new Dialog_1.Dialog({
            closeDialog: () => this.hide(),
            serviceContainer: this.serviceContainer,
        });
        this.dialogPanel = new DialogPanel(dialog);
        this.element.appendChild(this.minimizedPanel.getElement());
        this.element.appendChild(this.dialogPanel.getElement());
        document.addEventListener('deviceConnected', (event) => {
            const customEvent = event;
            if (customEvent.detail) {
                if (customEvent.detail.msg) {
                    console.log(customEvent.detail.msg);
                    this.updateOnConnection(customEvent.detail.msg);
                }
            }
        });
        document.addEventListener('deviceDisconnected', (event) => {
            const customEvent = event;
            if (customEvent.detail) {
                if (customEvent.detail.msg) {
                    console.log(customEvent.detail.msg);
                    this.updateOnDisconnection(customEvent.detail.msg);
                }
            }
        });
    }
    getElement() {
        return this.element;
    }
    updateOnConnection(connection_msg) {
        this.minimizedPanel.updateOnConnection(connection_msg);
    }
    updateOnDisconnection(connection_msg) {
        this.minimizedPanel.updateOnConnection(connection_msg);
    }
    show() {
        this.element.style.display = 'block';
        this.element.classList.remove('minimized');
        this.element.classList.add('visible');
        this.element.style.transition = 'opacity 0.3s ease-in-out';
        this.element.style.opacity = '1';
        this.dialogPanel.show();
        this.minimizedPanel.hide();
    }
    hide() {
        this.dialogPanel.hide();
        this.minimizedPanel.show();
    }
}
exports["default"] = WelcomePanel;


/***/ }),

/***/ "./lib/services/ConsoleService.js":
/*!****************************************!*\
  !*** ./lib/services/ConsoleService.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ConsoleService = void 0;
const ErrorHandler_1 = __webpack_require__(/*! ../utils/ErrorHandler */ "./lib/utils/ErrorHandler.js");
class ConsoleService {
    constructor(deviceService) {
        this.deviceService = deviceService;
    }
    async readAndParseOutput(streamCallback) {
        const logger = (msg, data) => console.debug(`[ConsoleService] readAndParseOutput - ${msg}`, data || '');
        logger('Starting to read output');
        let buffer = '';
        let outputStarted = false;
        let timeout = 10000;
        const startTime = Date.now();
        try {
            const transport = this.deviceService.getTransport();
            if (!transport || !transport.device.readable) {
                const error = 'Device transport not readable';
                logger(error);
                return {
                    success: false,
                    error
                };
            }
            logger('Transport is readable, waiting for data');
            while (true) {
                const { text, done } = await this.deviceService.readAndDecodeFromDevice();
                if (done) {
                    logger('Read operation done');
                    break;
                }
                if (text) {
                    buffer += text;
                    let current_buffer = text;
                    const truncate = (str, len = 50) => str.substring(0, len) + (str.length > len ? '...' : '');
                    logger('Received text', truncate(text));
                    logger('Current buffer', truncate(buffer));
                    if (!outputStarted && buffer.includes('######START REQUEST######')) {
                        logger('Start marker found');
                        outputStarted = true;
                        buffer = buffer.split('######START REQUEST######')[1];
                        current_buffer = buffer;
                    }
                    if (outputStarted) {
                        current_buffer = current_buffer.split('>>')[0];
                        logger('Streaming output');
                        streamCallback({
                            name: 'stdout',
                            text: current_buffer
                        });
                    }
                    if (outputStarted && buffer.includes('>>>')) {
                        const output = buffer.split('>>>')[0].trim();
                        logger('Output complete', truncate(output));
                        return { success: true };
                    }
                }
                if (Date.now() - startTime > timeout) {
                    logger('Timeout reached');
                    return {
                        success: false,
                        error: 'Command execution timed out'
                    };
                }
                await new Promise(resolve => setTimeout(resolve, 20));
            }
            logger('Completed successfully');
            return { success: true };
        }
        catch (err) {
            logger('Error occurred');
            return {
                success: false,
                error: ErrorHandler_1.ErrorHandler.getErrorMessage(err)
            };
        }
    }
    async executeCommand(code, streamCallback) {
        const logger = (msg, data) => console.debug(`[ConsoleService] executeCommand - ${msg}`, data || '');
        logger('Starting command execution');
        try {
            logger('Sending command to device');
            const sendSuccess = await this.deviceService.sendCommand(code);
            if (!sendSuccess) {
                logger('Failed to send command');
                return {
                    success: false,
                    error: 'Failed to send command to device'
                };
            }
            logger('Command sent, reading output');
            const result = await this.readAndParseOutput(streamCallback);
            logger('Command execution completed', { success: result.success });
            return result;
        }
        catch (err) {
            logger('Error occurred');
            return {
                success: false,
                error: ErrorHandler_1.ErrorHandler.getErrorMessage(err)
            };
        }
    }
    async resetConsole() {
        const logger = (msg) => console.debug(`[ConsoleService] resetConsole - ${msg}`);
        logger('Sending reset sequence');
        try {
            await this.deviceService.sendInterrupt();
            await new Promise(resolve => setTimeout(resolve, 500));
            const encoder = new TextEncoder();
            const newLine = encoder.encode('\r\n');
            const transport = this.deviceService.getTransport();
            if (transport && transport.device.writable) {
                const writer = transport.device.writable.getWriter();
                await writer.write(newLine);
                await writer.write(newLine);
                writer.releaseLock();
            }
            logger('Reset sequence complete');
        }
        catch (err) {
            logger(`Error during reset: ${ErrorHandler_1.ErrorHandler.getErrorMessage(err)}`);
        }
    }
}
exports.ConsoleService = ConsoleService;


/***/ }),

/***/ "./lib/services/DeviceService.js":
/*!***************************************!*\
  !*** ./lib/services/DeviceService.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DeviceService = void 0;
const esptool_js_1 = __webpack_require__(/*! esptool-js */ "webpack/sharing/consume/default/esptool-js/esptool-js");
class DeviceService {
    constructor() {
        this.port = null;
        this.transport = null;
        this.isDeviceConnected = false;
        this.deviceType = '';
        this.decoder = new TextDecoder();
    }
    async requestPort() {
        try {
            const port = await navigator.serial.requestPort();
            this.port = port;
            this.transport = new esptool_js_1.Transport(port);
        }
        catch (err) {
            console.error('Failed to get port:', err);
            throw err;
        }
    }
    async connect() {
        var _a;
        if (!this.port) {
            await this.requestPort();
        }
        if (!this.port) {
            throw new Error('No port selected');
        }
        try {
            if (this.isDeviceConnected) {
                console.log('Already connected, skipping connection');
                return;
            }
            if (!this.port.readable && !this.port.writable) {
                (_a = this.transport) === null || _a === void 0 ? void 0 : _a.connect();
            }
            else {
                console.log('Port is already open, skipping connection');
            }
            this.isDeviceConnected = true;
        }
        catch (err) {
            console.error('Failed to connect:', err);
            throw err;
        }
        const event = new CustomEvent("deviceConnected", {
            detail: { msg: "Connected" }
        });
        document.dispatchEvent(event);
    }
    async disconnect() {
        if (this.port) {
            try {
                if ((this.port.readable && this.port.readable.locked) ||
                    (this.port.writable && this.port.writable.locked)) {
                    console.warn('Serial port has locked streams. Cannot close directly.');
                    this.isDeviceConnected = false;
                    return;
                }
                await this.port.close();
                console.log('Device disconnected successfully');
            }
            catch (err) {
                console.error('Failed to disconnect:', err);
            }
            finally {
                this.isDeviceConnected = false;
            }
        }
        else {
            this.isDeviceConnected = false;
        }
        const event = new CustomEvent("deviceDisconnected", {
            detail: { msg: "Not connected" }
        });
        document.dispatchEvent(event);
    }
    async reset() {
        if (!this.port) {
            throw new Error('No port selected');
        }
        try {
            await this.port.setSignals({ dataTerminalReady: false });
            await new Promise(resolve => setTimeout(resolve, 100));
            await this.port.setSignals({ dataTerminalReady: true });
        }
        catch (err) {
            console.error('Failed to reset device:', err);
            throw err;
        }
    }
    getTransport() {
        return this.transport;
    }
    isConnected() {
        return this.isDeviceConnected;
    }
    setDeviceType(type) {
        this.deviceType = type;
        console.log(`Device type set to: ${type}`);
    }
    getDeviceType() {
        return this.deviceType;
    }
    clearPort() {
        if (this.port) {
            console.log('Clearing device port reference');
            this.port = null;
            this.transport = null;
        }
        this.isDeviceConnected = false;
    }
    async sendCommand(code) {
        if (!this.transport || !this.transport.device.writable) {
            return false;
        }
        try {
            const encoder = new TextEncoder();
            const ctrl_d = new Uint8Array([4]);
            const ctrl_e = new Uint8Array([5]);
            const new_line = encoder.encode('\r\n');
            const writer = this.transport.device.writable.getWriter();
            await writer.write(ctrl_e);
            await writer.write(new_line);
            const data = encoder.encode(code + "######START REQUEST######");
            await writer.write(data);
            await writer.write(ctrl_d);
            await writer.write(new_line);
            writer.releaseLock();
            return true;
        }
        catch (error) {
            console.error('Error sending command to device:', error);
            return false;
        }
    }
    async sendInterrupt() {
        if (!this.transport || !this.transport.device.writable) {
            return false;
        }
        try {
            const encoder = new TextEncoder();
            const ctrl_c = new Uint8Array([3]);
            const new_line = encoder.encode('\r\n');
            const writer = this.transport.device.writable.getWriter();
            await writer.write(ctrl_c);
            await writer.write(new_line);
            writer.releaseLock();
            return true;
        }
        catch (error) {
            console.error('Error sending interrupt to device:', error);
            return false;
        }
    }
    async readFromDevice() {
        if (!this.transport || !this.transport.device.readable) {
            console.error('Transport not readable in readFromDevice');
            return { value: undefined, done: true };
        }
        try {
            const readLoop = this.transport.rawRead();
            return await readLoop.next();
        }
        catch (error) {
            console.error('Error reading from device:', error);
            return { value: undefined, done: true };
        }
    }
    async readAndDecodeFromDevice() {
        const { value, done } = await this.readFromDevice();
        console.log('[readAndDecodeFromDevice] ', value);
        if (done || !value) {
            return { text: '', done: true };
        }
        const text = this.decoder.decode(value);
        return { text, done: false };
    }
}
exports.DeviceService = DeviceService;


/***/ }),

/***/ "./lib/services/FirmwareService.js":
/*!*****************************************!*\
  !*** ./lib/services/FirmwareService.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.FirmwareService = void 0;
const constants_1 = __webpack_require__(/*! ../constants */ "./lib/constants.js");
class FirmwareService {
    constructor(deviceService) {
        this.deviceService = deviceService;
        this.firmwareString = null;
        this.firmwareBlob = null;
        this.selectedFirmwareId = 'Auto';
        const savedSelection = localStorage.getItem('selectedFirmwareId');
        if (savedSelection) {
            this.selectedFirmwareId = savedSelection;
        }
        else {
            this.selectedFirmwareId = 'auto';
        }
    }
    getFirmwareOptions() {
        return constants_1.firmwareOptions;
    }
    getSelectedFirmwareId() {
        return this.selectedFirmwareId;
    }
    setSelectedFirmwareId(id) {
        if (id in constants_1.firmwareOptions) {
            this.selectedFirmwareId = id;
            this.firmwareString = null;
            this.firmwareBlob = null;
            localStorage.removeItem('cachedFirmware');
            localStorage.setItem('selectedFirmwareId', id);
        }
    }
    async downloadFirmware() {
        const savedFirmwareId = localStorage.getItem('selectedFirmwareId');
        if (savedFirmwareId) {
            this.selectedFirmwareId = savedFirmwareId;
        }
        if (this.selectedFirmwareId === 'auto') {
            return this.downloadAutoDetectedFirmware();
        }
        else {
            return this.downloadSpecificFirmware(this.selectedFirmwareId);
        }
    }
    async downloadAutoDetectedFirmware() {
        const deviceType = this.deviceService.getDeviceType();
        let firmwareId;
        if (!deviceType) {
            console.warn('No device detected for auto firmware detection. Using generic ESP32 firmware.');
            firmwareId = 'esp32';
        }
        else if (deviceType.includes('C6')) {
            console.log('Auto-detected ESP32-C6, using corresponding firmware');
            firmwareId = 'esp32-c6';
        }
        else if (deviceType.includes('C3')) {
            console.log('Auto-detected ESP32-C3, using corresponding firmware');
            firmwareId = 'esp32-c3';
        }
        else {
            console.log('Auto-detected generic ESP32, using corresponding firmware');
            firmwareId = 'esp32';
        }
        return this.downloadSpecificFirmware(firmwareId);
    }
    async downloadSpecificFirmware(firmwareId) {
        const selectedFirmware = constants_1.firmwareOptions[firmwareId];
        if (!selectedFirmware || !selectedFirmware.url) {
            throw new Error(`Invalid firmware selection or no URL for: ${firmwareId}`);
        }
        const result = await fetch(selectedFirmware.url, {
            mode: 'cors',
            headers: {
                'Accept': 'application/octet-stream',
            }
        });
        if (!result.ok) {
            throw new Error(`Failed to fetch firmware: ${result.status} ${result.statusText}`);
        }
        this.firmwareBlob = await result.blob();
        const uint8Array = new Uint8Array(await this.firmwareBlob.arrayBuffer());
        this.firmwareString = Array.from(uint8Array)
            .map(byte => String.fromCharCode(byte))
            .join('');
        return this.firmwareString;
    }
}
exports.FirmwareService = FirmwareService;


/***/ }),

/***/ "./lib/services/FlashService.js":
/*!**************************************!*\
  !*** ./lib/services/FlashService.js ***!
  \**************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.FlashService = void 0;
const esptool_js_1 = __webpack_require__(/*! esptool-js */ "webpack/sharing/consume/default/esptool-js/esptool-js");
const CryptoJS = __importStar(__webpack_require__(/*! crypto-js */ "webpack/sharing/consume/default/crypto-js/crypto-js"));
const ProgressOverlay_1 = __webpack_require__(/*! ../components/ProgressOverlay */ "./lib/components/ProgressOverlay.js");
const ErrorHandler_1 = __webpack_require__(/*! ../utils/ErrorHandler */ "./lib/utils/ErrorHandler.js");
class FlashService {
    constructor(deviceService, consoleService, firmwareService) {
        this.deviceService = deviceService;
        this.consoleService = consoleService;
        this.firmwareService = firmwareService;
    }
    static getInstance() {
        throw new Error('FlashService.getInstance is deprecated. Use dependency injection instead.');
    }
    async flashDevice() {
        const progressOverlay = new ProgressOverlay_1.ProgressOverlay();
        try {
            const transport = this.deviceService.getTransport();
            if (!transport) {
                throw new Error('Failed to get device transport');
            }
            try {
                await transport.disconnect();
            }
            catch (err) { }
            const currentFirmware = this.firmwareService.getSelectedFirmwareId();
            progressOverlay.show(currentFirmware);
            const loaderOptions = {
                transport: transport,
                baudrate: 921600,
                romBaudrate: 115600
            };
            const esploader = new esptool_js_1.ESPLoader(loaderOptions);
            if (transport && transport.device) {
                const port = transport.device;
                const readLocked = port.readable ? port.readable.locked || false : false;
                const writeLocked = port.writable ? port.writable.locked || false : false;
                console.log('Stream state before esploader.main():', {
                    readLocked,
                    writeLocked,
                    port
                });
            }
            progressOverlay.setStatus('Connecting to device...');
            const deviceInfo = await esploader.main();
            console.log("[flashDevice] current device is", deviceInfo);
            if (transport && transport.device) {
                const port = transport.device;
                const readLocked = port.readable ? port.readable.locked || false : false;
                const writeLocked = port.writable ? port.writable.locked || false : false;
                console.log('Stream state after esploader.main():', {
                    readLocked,
                    writeLocked,
                    port,
                }, esploader.transport.device);
                // await port.close()
            }
            if (deviceInfo) {
                console.log(deviceInfo);
                const match = deviceInfo.match(/ESP32[-\w]*/i);
                if (match) {
                    const chipType = match[0].toUpperCase();
                    console.log(`🔍 Auto-detected device: ${chipType}`);
                    this.deviceService.setDeviceType(chipType);
                    const deviceConnectedEvent = new CustomEvent('deviceConnected', {
                        detail: { deviceType: chipType }
                    });
                    document.dispatchEvent(deviceConnectedEvent);
                    const currentSelection = this.firmwareService.getSelectedFirmwareId();
                    if (currentSelection === 'Auto') {
                        let targetFirmware = 'esp32';
                        if (chipType.includes('C6')) {
                            targetFirmware = 'esp32-c6';
                        }
                        else if (chipType.includes('C3')) {
                            targetFirmware = 'esp32-c3';
                        }
                        this.firmwareService.setSelectedFirmwareId(targetFirmware);
                        console.log(`✓ Auto-detection: Using ${targetFirmware} firmware for ${chipType}`);
                        progressOverlay.setStatus(`Auto-detected ${chipType}. Using ${targetFirmware} firmware...`);
                        progressOverlay.setTitle(`Flashing ${targetFirmware} Firmware...`);
                    }
                    else {
                        console.log(`⚠️ Manual firmware selection: Using ${currentSelection} firmware (device: ${chipType})`);
                        progressOverlay.setStatus(`Using manually selected ${currentSelection} firmware...`);
                        progressOverlay.setTitle(`Flashing ${currentSelection} Firmware...`);
                    }
                }
                else {
                    console.warn(`⚠️ Could not determine chip type from device info. Using default firmware.`);
                }
            }
            progressOverlay.setStatus('Downloading firmware...');
            let firmwareString = await this.firmwareService.downloadFirmware();
            const flashOptions = {
                fileArray: [{
                        data: firmwareString,
                        address: 0x0
                    }],
                flashSize: "keep",
                eraseAll: false,
                compress: true,
                flashMode: "dio",
                flashFreq: "40m",
                reportProgress: (fileIndex, written, total) => {
                    progressOverlay.updateProgress(written, total);
                    console.log('Flash progress:', { fileIndex, written, total });
                },
                calculateMD5Hash: (image) => CryptoJS.MD5(CryptoJS.enc.Latin1.parse(image)).toString()
            };
            if (transport && transport.device) {
                const port = transport.device;
                const readLocked = port.readable ? port.readable.locked || false : false;
                const writeLocked = port.writable ? port.writable.locked || false : false;
                console.log('Stream state before flashing:', {
                    readLocked,
                    writeLocked
                });
            }
            await esploader.writeFlash(flashOptions);
            progressOverlay.setStatus('Flash complete!');
            if (transport && transport.device) {
                const port = transport.device;
                const readLocked = port.readable ? port.readable.locked || false : false;
                const writeLocked = port.writable ? port.writable.locked || false : false;
                console.log('Stream state after flashing:', {
                    readLocked,
                    writeLocked
                });
                progressOverlay.setStatus(`Flash complete! Streams: Read ${readLocked ? 'LOCKED' : 'unlocked'}, Write ${writeLocked ? 'LOCKED' : 'unlocked'}`);
            }
            const flashCompleteEvent = new CustomEvent('flashComplete', {
                detail: { success: true }
            });
            document.dispatchEvent(flashCompleteEvent);
            await new Promise(resolve => setTimeout(resolve, 1000));
            console.log('Hard resetting via RTS pin...');
            try {
                await esploader.after();
                const transportAfter = this.deviceService.getTransport();
                if (transportAfter && transportAfter.device) {
                    const port = transportAfter.device;
                    const readLocked = port.readable ? port.readable.locked || false : false;
                    const writeLocked = port.writable ? port.writable.locked || false : false;
                    console.log('Stream state after esploader.after():', {
                        readLocked,
                        writeLocked
                    });
                    progressOverlay.setStatus(`After ESP reset. Streams: Read ${readLocked ? 'LOCKED' : 'unlocked'}, Write ${writeLocked ? 'LOCKED' : 'unlocked'}`);
                }
            }
            catch (afterError) {
                console.warn('Error during esploader.after():', afterError);
            }
            try {
                const transportBeforeReset = this.deviceService.getTransport();
                if (transportBeforeReset && transportBeforeReset.device) {
                    const port = transportBeforeReset.device;
                    const readLocked = port.readable ? port.readable.locked || false : false;
                    const writeLocked = port.writable ? port.writable.locked || false : false;
                    console.log('Stream state before device reset:', {
                        readLocked,
                        writeLocked
                    });
                }
                progressOverlay.setStatus('Resetting device...');
                await this.deviceService.reset();
                await new Promise(resolve => setTimeout(resolve, 1000));
                progressOverlay.setStatus('Initializing console...');
                await this.consoleService.resetConsole();
                await new Promise(resolve => setTimeout(resolve, 500));
            }
            catch (resetError) {
                console.warn('Error during device reset:', resetError);
            }
            await new Promise(resolve => setTimeout(resolve, 500));
            await transport.disconnect();
            try {
                const transportBeforeDisconnect = this.deviceService.getTransport();
                if (transportBeforeDisconnect && transportBeforeDisconnect.device) {
                    const port = transportBeforeDisconnect.device;
                    const readLocked = port.readable ? port.readable.locked || false : false;
                    const writeLocked = port.writable ? port.writable.locked || false : false;
                    console.log('Stream state before disconnect:', {
                        readLocked,
                        writeLocked
                    });
                    progressOverlay.setStatus(`Cleaning up... Streams: Read ${readLocked ? 'LOCKED' : 'unlocked'}, Write ${writeLocked ? 'LOCKED' : 'unlocked'}`);
                    if (readLocked || writeLocked) {
                        console.log('Waiting for streams to unlock before disconnect...');
                        await new Promise(resolve => setTimeout(resolve, 1000));
                    }
                }
                else {
                    progressOverlay.setStatus('Cleaning up connections...');
                }
            }
            catch (disconnectError) {
                console.warn('Error during device disconnect:', disconnectError);
            }
            console.warn('Reconnect...');
            await transport.connect();
            await this.deviceService.reset();
            console.warn('Device reset...');
            const deviceType = this.deviceService.getDeviceType();
            if (deviceType) {
                const deviceConnectedEvent = new CustomEvent('deviceConnected', {
                    detail: { deviceType }
                });
                document.dispatchEvent(deviceConnectedEvent);
            }
        }
        catch (err) {
            const errorMessage = ErrorHandler_1.ErrorHandler.getErrorMessage(err);
            progressOverlay.setStatus(`Flash failed: ${errorMessage}`);
            await new Promise(resolve => setTimeout(resolve, 2000));
        }
        finally {
            await progressOverlay.hide();
        }
    }
}
exports.FlashService = FlashService;


/***/ }),

/***/ "./lib/services/ServiceContainer.js":
/*!******************************************!*\
  !*** ./lib/services/ServiceContainer.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ServiceContainer = void 0;
const DeviceService_1 = __webpack_require__(/*! ./DeviceService */ "./lib/services/DeviceService.js");
const ConsoleService_1 = __webpack_require__(/*! ./ConsoleService */ "./lib/services/ConsoleService.js");
const FirmwareService_1 = __webpack_require__(/*! ./FirmwareService */ "./lib/services/FirmwareService.js");
const FlashService_1 = __webpack_require__(/*! ./FlashService */ "./lib/services/FlashService.js");
class ServiceContainer {
    constructor() {
        this._deviceService = new DeviceService_1.DeviceService();
        this._consoleService = new ConsoleService_1.ConsoleService(this._deviceService);
        this._firmwareService = new FirmwareService_1.FirmwareService(this._deviceService);
        this._flashService = new FlashService_1.FlashService(this._deviceService, this._consoleService, this._firmwareService);
    }
    get deviceService() {
        return this._deviceService;
    }
    get consoleService() {
        return this._consoleService;
    }
    get firmwareService() {
        return this._firmwareService;
    }
    get flashService() {
        return this._flashService;
    }
}
exports.ServiceContainer = ServiceContainer;


/***/ }),

/***/ "./lib/styles.js":
/*!***********************!*\
  !*** ./lib/styles.js ***!
  \***********************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.buttonStyles = exports.cardStyles = exports.minimizedStyles = exports.dialogStyles = exports.progressOverlayStyles = exports.overlayStyles = exports.animations = exports.globalStyles = void 0;
exports.globalStyles = `
  :root {
    --ui-red: #FF3B30;
    --ui-red-dark: #E0321F;
    --ui-red-light: #FF6961;
    --ui-navy: #0A192F;
    --ui-navy-light: #2D2D3A;
    --ui-white: #FFFFFF;
    --ui-gray: #8E8E93;
    --ui-gray-light: #F2F2F7;
    --ui-shadow-sm: 0 2px 8px rgba(28, 28, 40, 0.08);
    --ui-shadow-md: 0 8px 24px rgba(28, 28, 40, 0.12);
    --ui-shadow-lg: 0 20px 40px rgba(28, 28, 40, 0.16);
  }
`;
exports.animations = `
  @keyframes float {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-4px); }
  }

  @keyframes fadeInUp {
    from {
      opacity: 0;
      transform: translateY(12px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  @keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
  }
`;
exports.overlayStyles = `
  .welcome-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 1000;
    opacity: 1;
    transition: opacity 0.3s ease-in-out, visibility 0.3s ease-in-out;
  }

  .jp-kernel-welcome-panel.visible .welcome-overlay {
    opacity: 1;
    visibility: visible;
  }
`;
exports.progressOverlayStyles = `
  .progress-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0, 0, 0, 0.7);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 2000;
    opacity: 0;
    transition: opacity 0.3s ease;
  }

  .progress-overlay.visible {
    opacity: 1;
  }

  .progress-container {
    background: white;
    border-radius: 8px;
    padding: 24px;
    width: 400px;
    max-width: 90%;
    box-shadow: var(--ui-shadow-lg);
  }

  .progress-title {
    font-size: 18px;
    font-weight: 600;
    margin-bottom: 16px;
    color: var(--ui-navy);
    display: flex;
    align-items: center;
  }
  
  /* Styling for firmware name in progress title */
  .progress-title .firmware-name {
    color: var(--ui-red);
    font-weight: 700;
    margin: 0 4px;
  }

  .progress-bar-container {
    height: 8px;
    background: var(--ui-gray-light);
    border-radius: 4px;
    overflow: hidden;
    margin-bottom: 12px;
  }

  .progress-bar {
    height: 100%;
    background: var(--ui-red);
    width: 0%;
    transition: width 0.3s ease;
  }

  .progress-status {
    font-size: 14px;
    color: var(--ui-gray);
    margin-top: 8px;
  }
`;
exports.dialogStyles = `
  .welcome-dialog {
    background: white;
    border-radius: 8px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    width: 90%;
    max-width: 500px;
    padding: 2rem;
    position: relative;
    transform: translateY(20px);
    opacity: 1;
    transition: transform 0.3s ease-in-out, opacity 0.3s ease-in-out;
  }

  .jp-kernel-welcome-panel.visible .welcome-dialog {
    transform: translateY(0);
    opacity: 1;
  }

  .firmware-section {
    width: 100%;
    margin-top: 0.75rem;
    animation: fadeIn 0.5s ease-out forwards;
  }
  
  .firmware-divider {
    height: 1px;
    width: 100%;
    background-color: var(--ui-gray-light);
    margin: 0.5rem 0;
  }
  
  .device-info {
    margin: 0.5rem 0;
    font-size: 0.95rem;
    color: var(--ui-gray-darker);
  }
  
  .device-detected, .device-not-detected, .device-auto-mode {
    display: flex;
    flex-direction: column;
    padding: 0.8rem;
    border-radius: 6px;
    margin-bottom: 0.5rem;
    transition: all 0.3s ease;
  }
  
  .device-detected {
    background-color: rgba(40, 167, 69, 0.08);
    border-left: 4px solid var(--ui-green);
  }
  
  .device-detected-header, .device-auto-header {
    display: flex;
    align-items: center;
    margin-bottom: 0.5rem;
    font-weight: 500;
  }
  
  .device-status {
    font-size: 1rem;
  }
  
  .device-details {
    display: flex;
    flex-direction: column;
    gap: 0.3rem;
    padding-left: 1.8rem;
  }
  
  .firmware-badge {
    display: inline-block;
    background-color: rgba(40, 167, 69, 0.15);
    padding: 0.2rem 0.5rem;
    border-radius: 4px;
    font-size: 0.85rem;
    margin-top: 0.3rem;
    font-weight: 500;
  }
  
  .device-not-detected {
    background-color: rgba(255, 193, 7, 0.08);
    border-left: 4px solid var(--ui-orange);
  }
  
  .device-manual-mode {
    padding-left: 1.8rem;
  }
  
  .device-auto-mode {
    background-color: rgba(13, 110, 253, 0.08);
    border-left: 4px solid var(--ui-blue);
    animation: pulse 2s infinite;
  }
  
  .device-action-hint {
    padding-left: 1.8rem;
    font-size: 0.95rem;
  }
  
  @keyframes pulse {
    0% {
      box-shadow: 0 0 0 0 rgba(0, 122, 255, 0.1);
    }
    70% {
      box-shadow: 0 0 0 6px rgba(0, 122, 255, 0);
    }
    100% {
      box-shadow: 0 0 0 0 rgba(0, 122, 255, 0);
    }
  }
  
  .device-icon {
    margin-right: 0.7rem;
    font-size: 1.2rem;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  
  .device-icon.success {
    color: var(--ui-green);
  }
  
  .device-icon.warning {
    color: var(--ui-orange);
  }
  
  .device-icon.waiting {
    color: var(--ui-blue);
  }
  
  .device-status.waiting {
    color: var(--ui-blue);
    font-weight: 500;
  }
  
  .firmware-dropdown-container {
    margin: 0.8rem 0;
    width: 100%;
    display: flex;
    align-items: center;
  }
  
  .firmware-dropdown-label {
    display: inline-block;
    margin-right: 0.8rem;
    font-size: 0.95rem;
    font-weight: 500;
    min-width: 6rem;
    color: var(--ui-navy);
  }
  
  .firmware-selector {
    flex: 1;
    padding: 0.6rem 0.8rem;
    border-radius: 6px;
    border: 1px solid var(--ui-gray-light);
    background-color: var(--ui-white);
    color: var(--ui-navy);
    font-size: 0.95rem;
    transition: border-color 0.2s, box-shadow 0.2s;
  }
  
  .firmware-selector:focus {
    outline: none;
    border-color: var(--ui-blue);
    box-shadow: 0 0 0 3px rgba(13, 110, 253, 0.25);
  }
  
  .firmware-selector:hover {
    border-color: var(--ui-blue);
  }
  
  /* Add styles for the tooltip */
  .tooltip-container {
    margin-top: 0.8rem;
    font-size: 0.85rem;
    color: var(--ui-gray-darker);
    display: flex;
    align-items: flex-start;
    padding: 0.8rem;
    background-color: rgba(13, 110, 253, 0.05);
    border-radius: 6px;
    border-left: 3px solid var(--ui-blue);
  }
  
  .tooltip-icon {
    margin-right: 0.5rem;
    color: var(--ui-blue);
    font-size: 1rem;
  }
  
  .tooltip-text {
    flex: 1;
    line-height: 1.5;
  }
  
  /* Add extra padding to the flash card */
  [data-action="flash"] .card-content {
    padding-bottom: 0.5rem;
    flex-direction: column;
    align-items: flex-start;
  }
  
  /* Flash card header section that contains icon, title and description */
  [data-action="flash"] .card-header {
    display: flex;
    align-items: center;
    width: 100%;
  }
  
  .welcome-title {
    font-size: 24px;
    margin: 0 0 1.5rem 0;
    color: var(--ui-navy);
    text-align: center;
  }

  .close-button {
    position: absolute;
    top: 1rem;
    right: 1rem;
    background: none;
    border: none;
    font-size: 24px;
    cursor: pointer;
    color: #666;
    padding: 0.5rem;
    line-height: 1;
    transition: color 0.2s ease-in-out;
  }

  .close-button:hover {
    color: #333;
  }
`;
exports.minimizedStyles = `
  .esp-button-container {
    position: fixed;
    bottom: 2rem;
    right: 2rem;
    z-index: 1000;
  }

  .minimized-button {
    width: 120px;
    height: 120px;
    border-radius: 50%;
    background: white;
    border: none;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
    transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
    padding: 12px;
    overflow: hidden;
  }
  
  .button-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 100%;
    gap: 8px;
  }

  .minimized-button img {
    width: 60px;
    height: 60px;
    object-fit: contain;
  }
  
  .status-wrapper {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 4px;
    margin-top: 4px;
  }

  .status-indicator {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background-color: #e74c3c;
    display: inline-block;
  }

  .status-indicator.connected {
    background-color: #2ecc71;
  }

  .device-label {
    font-size: 11px;
    color: #555;
    text-align: center;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-weight: bold;
    line-height: 1.2;
  }

  .minimized-button:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
  }

  .minimized-button:active {
    transform: scale(0.95);
  }

  .jp-kernel-welcome-panel.minimized .welcome-overlay {
    opacity: 0;
    visibility: hidden;
  }

  .jp-kernel-welcome-panel.minimizing .welcome-dialog {
    transform: translate(calc(50vw - 32px), calc(50vh - 32px)) scale(0.1);
    opacity: 0;
  }
`;
exports.cardStyles = `
  .welcome-card {
    opacity: 0;
    transform: translateY(12px);
    animation: fadeInUp 0.5s cubic-bezier(0.16, 1, 0.3, 1) forwards;
    background: var(--ui-white) !important;
    border: 1.5px solid var(--ui-gray-light) !important;
    border-radius: 16px !important;
    padding: 1.25rem !important;
    cursor: pointer;
    transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1) !important;
    margin-bottom: 0.75rem;
    position: relative;
    overflow: hidden;
  }

  .welcome-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(120deg, var(--ui-red), var(--ui-red-dark));
    opacity: 0;
    transition: opacity 0.3s ease;
    z-index: 0;
  }

  .welcome-card:hover {
    transform: translateY(-2px) scale(1.02);
    border-color: var(--ui-red) !important;
    box-shadow: var(--ui-shadow-md),
                0 0 0 1px var(--ui-red),
                0 0 0 4px rgba(255, 59, 48, 0.12);
  }

  .welcome-card:hover::before {
    opacity: 1;
  }

  .welcome-card:active {
    transform: translateY(0) scale(0.98);
  }

  .card-content {
    position: relative;
    z-index: 1;
    display: flex;
    align-items: center;
  }

  .welcome-card:hover .welcome-icon,
  .welcome-card:hover .card-title,
  .welcome-card:hover .card-description {
    color: var(--ui-white) !important;
  }

  .welcome-card:nth-child(1) { animation-delay: 0.1s; }
  .welcome-card:nth-child(2) { animation-delay: 0.2s; }
  .welcome-card:nth-child(3) { animation-delay: 0.3s; }

  .welcome-icon {
    font-size: 2rem;
    margin-right: 1.25rem;
    color: var(--ui-red);
    transition: all 0.3s ease;
    text-shadow: var(--ui-shadow-sm);
  }

  .welcome-title {
    color: var(--ui-navy);
    font-size: 1.75rem !important;
    margin: 0 0 1.75rem !important;
    font-weight: 700;
    letter-spacing: -0.5px;
    line-height: 1.2;
  }

  .card-title {
    color: var(--ui-navy);
    font-weight: 600;
    font-size: 1.1rem;
    margin-bottom: 0.375rem;
    transition: color 0.3s ease;
    letter-spacing: -0.3px;
  }

  .card-description {
    color: var(--ui-gray);
    font-size: 0.9375rem;
    transition: color 0.3s ease;
    line-height: 1.4;
  }

  .action-card {
    display: flex;
    align-items: center;
    padding: 1rem;
    border-radius: 8px;
    cursor: pointer;
    transition: transform 0.2s, box-shadow 0.2s;
    background: white;
    border: 1px solid #eee;
  }

  .action-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  }

  .action-card .icon {
    font-size: 24px;
    margin-right: 1rem;
  }

  .action-card .content {
    flex: 1;
  }

  .action-card .title {
    font-weight: bold;
    margin: 0;
    color: var(--ui-navy);
  }

  .action-card .description {
    margin: 0.25rem 0 0;
    font-size: 0.9rem;
    color: #666;
  }
`;
exports.buttonStyles = `
  .close-button {
    position: absolute;
    top: 1.25rem;
    right: 1.25rem;
    cursor: pointer;
    color: var(--ui-gray);
    background: var(--ui-gray-light);
    border: none;
    font-size: 1.25rem;
    padding: 0;
    border-radius: 50%;
    width: 36px;
    height: 36px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    opacity: 0.9;
    transform-origin: center;
  }

  .close-button:hover {
    color: var(--ui-white);
    background: var(--ui-red);
    opacity: 1;
    transform: scale(1.1);
    box-shadow: var(--ui-shadow-sm);
  }

  .close-button:active {
    transform: scale(0.95);
  }

  .action-button {
    background: var(--ui-navy);
    color: white;
    border: none;
    padding: 0.75rem 1.5rem;
    border-radius: 4px;
    cursor: pointer;
    font-weight: bold;
    transition: background-color 0.2s;
  }

  .action-button:hover {
    background: #1a2f4c;
  }
`;


/***/ }),

/***/ "./lib/utils/ErrorHandler.js":
/*!***********************************!*\
  !*** ./lib/utils/ErrorHandler.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ErrorHandler = void 0;
class ErrorHandler {
    static getErrorMessage(err) {
        if (err instanceof Error) {
            return err.message;
        }
        if (typeof err === 'string') {
            return err;
        }
        return 'Unknown error occurred';
    }
    static async handleError(err, context) {
        const message = this.getErrorMessage(err);
        console.error(`${context} error:`, err);
        return Promise.reject(new Error(`${context}: ${message}`));
    }
}
exports.ErrorHandler = ErrorHandler;


/***/ })

}]);
//# sourceMappingURL=lib_index_js.514d072333225cb81367.js.map